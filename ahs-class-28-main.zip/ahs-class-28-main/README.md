# ahs-class-28
This is a page for the class of 28
